package com.example.ApiClinica.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "Paciente")

public class Paciente {
   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pacienteId;
    private String firstName;
    private String lastName;
    @Column (name = "Correo_electronico", unique = true, nullable = false)
    private String email;

}
