package com.example.ApiClinica.controller;

import com.example.ApiClinica.entity.Cita;
import com.example.ApiClinica.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    @GetMapping
    public List<Cita> getAll() {
        return citaService.getCitas();
    }

    @GetMapping("/{citaId}")
    public ResponseEntity<Cita> getById(@PathVariable Long citaId) {
        Optional<Cita> cita = citaService.getCita(citaId);
        return cita.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Void> create(@RequestBody Cita cita) {
        citaService.saveOrUpdate(cita);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{citaId}")
    public ResponseEntity<Cita> update(@PathVariable Long citaId, @RequestBody Cita cita) {
        Optional<Cita> existingCita = citaService.getCita(citaId);
        if (existingCita.isPresent()) {
            cita.setCitaId(citaId);
            citaService.saveOrUpdate(cita);
            return ResponseEntity.ok(cita);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{citaId}")
    public ResponseEntity<Void> delete(@PathVariable Long citaId) {
        Optional<Cita> cita = citaService.getCita(citaId);
        if (cita.isPresent()) {
            citaService.delete(citaId);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
