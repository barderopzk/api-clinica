package com.example.ApiClinica.service;

import com.example.ApiClinica.entity.Cita;
import com.example.ApiClinica.repositorio.CitaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CitaService {

    @Autowired
    private CitaRepositorio citaRepositorio;

    public List<Cita> getCitas() {
        return citaRepositorio.findAll();
    }

    public Optional<Cita> getCita(Long id) {
        return citaRepositorio.findById(id);
    }

    public void saveOrUpdate(Cita cita) {
        citaRepositorio.save(cita);
    }

    public void delete(Long id) {
        citaRepositorio.deleteById(id);
    }
}
