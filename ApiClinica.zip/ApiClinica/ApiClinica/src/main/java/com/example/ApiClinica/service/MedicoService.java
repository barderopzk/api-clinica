package com.example.ApiClinica.service;

import com.example.ApiClinica.entity.Medico;
import com.example.ApiClinica.repositorio.MedicoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicoService {

    @Autowired
    private MedicoRepositorio medicoRepositorio;

    public List<Medico> getMedicos() {
        return medicoRepositorio.findAll();
    }

    public Optional<Medico> getMedico(Long id) {
        return medicoRepositorio.findById(id);
    }

    public void saveOrUpdate(Medico medico) {
        medicoRepositorio.save(medico);
    }

    public void delete(Long id) {
        medicoRepositorio.deleteById(id);
    }
}
