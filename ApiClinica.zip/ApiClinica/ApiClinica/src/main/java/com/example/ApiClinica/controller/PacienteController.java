package com.example.ApiClinica.controller;

import com.example.ApiClinica.entity.Paciente;
import com.example.ApiClinica.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/pacientes")

public class PacienteController {

    @Autowired
    private PacienteService pacienteService;


    public PacienteController(PacienteService pacienteService) {
        this.pacienteService = pacienteService;
    }

    @GetMapping
    public List<Paciente> getAll() {
        return pacienteService.getPacientes();
    }

    @GetMapping("/{studentId}")
    public Optional<Paciente> getById(@PathVariable("pacienteId") Long pacienteId) {
        return pacienteService.getPaciente(pacienteId);
    }

    @PostMapping
    public void saveUpdate(@RequestBody Paciente paciente) {
        pacienteService.saveOrUpdate(paciente);
    }

    @DeleteMapping("/{pacienteId}")
    public void saveUpdate(@PathVariable("pacienteId") Long pacienteId) {
        pacienteService.delete(pacienteId);
    }
}
