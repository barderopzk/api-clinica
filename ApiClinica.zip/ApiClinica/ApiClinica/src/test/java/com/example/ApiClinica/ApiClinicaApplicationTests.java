package com.example.ApiClinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
